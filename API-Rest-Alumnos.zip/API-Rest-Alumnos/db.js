// db.js
const { Sequelize } = require('sequelize');
require('dotenv').config();

// Depurar para ver si las variables se están cargando
console.log('DB Config:', {
  DB_NAME: process.env.DB_NAME,
  DB_USER: process.env.DB_USER,
  DB_PASS: process.env.DB_PASS,
  DB_HOST: process.env.DB_HOST,
  DB_DIALECT: process.env.DB_DIALECT
});

const sequelize = new Sequelize(
    process.env.DB_NAME,      // Nombre de la base de datos
    process.env.DB_USER,      // Usuario de la base de datos
    process.env.DB_PASS,      // Contraseña de la base de datos
    {
        host: process.env.DB_HOST,       // Host de la base de datos
        port: process.env.DB_PORT,       // Puerto de la base de datos
        dialect: 'mysql'                 // Dialecto de la base de datos, en este caso "mysql"
    }
);


module.exports = sequelize;

// Probar la conexión a la base de datos
sequelize.authenticate()
    .then(() => {
        console.log('Conexión a la base de datos establecida exitosamente.');
    })
    .catch(error => {
        console.error('No se pudo conectar a la base de datos:', error);
    });
