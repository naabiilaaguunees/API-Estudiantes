const { DataTypes } = require('sequelize');
const sequelize = require('../db'); // Importa la instancia de sequelize

const Estudiante = sequelize.define('Estudiante', {
    nombre: {
        type: DataTypes.STRING,
        allowNull: false
    },
    edad: {
        type: DataTypes.INTEGER
    },
    inscrito: {
        type: DataTypes.BOOLEAN
    }
});

module.exports = Estudiante;
