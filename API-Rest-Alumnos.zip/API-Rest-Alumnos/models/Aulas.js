const { DataTypes } = require('sequelize');
const sequelize = require('../db'); // Importa la instancia de sequelize

const Aulas = sequelize.define('aulas', {
    salon: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    materia: {
        type: DataTypes.CHAR
    },
    docente: {
        type: DataTypes.CHAR
    }
});

module.exports = Aulas;