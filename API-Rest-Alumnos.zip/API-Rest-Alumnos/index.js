const { Parser } = require('json2csv');
require('dotenv').config();
const express = require('express');
const app = express();
const sequelize = require('./db'); // Importa la conexión
const Estudiante = require('./models/Estudiantes'); // Importa el modelo
const Aulas = require('./models/Aulas');

app.use(express.json());

// Arrays locales para pruebas (nota: estos están duplicando lo que debería estar en la base de datos)
const estudiantes = [
    { id: 1, nombre: 'Gonzalo', edad: 22, inscrito: true },
    { id: 2, nombre: 'Santiago', edad: 21, inscrito: true },
    { id: 3, nombre: 'Carlos', edad: 21, inscrito: true },
];

const aulas = [
    { salon: 8102, materia: 'Ciencias', docente: "Estrellita"},
    { salon: 8203, materia: 'Historia', docente: "Flor"},
    { salon: 8304, materia: 'Geografia', docente: "Gabriel"}
];

app.get('/', (req, res) => {
    res.send('Prueba uno de API');
});

app.get('/api/estudiantes', (req, res) => {
    Estudiante.findAll()
        .then(function(estudiantes) {
            console.log({ estudiantes });
            res.send(estudiantes.map(function(estudiante) {
                return estudiante; // Aquí puedes transformar los datos si es necesario
            }));
        })
        .catch(function(error) {
            console.error('Error al obtener estudiantes:', error);
            res.status(500).send({ error: 'Error al obtener estudiantes' });
        });
});

app.get('/api/estudiantes/:id', (req, res) => {
    // Esta ruta debería usar Sequelize en lugar del array local
    Estudiante.findByPk(parseInt(req.params.id))
        .then(estudiante => {
            if (!estudiante) return res.status(404).send('Estudiante no encontrado');
            res.send(estudiante);
        })
        .catch(error => {
            console.error('Error al buscar estudiante:', error);
            res.status(500).send({ error: 'Error al buscar estudiante' });
        });
});

app.post('/api/estudiantes', (req, res) => {
    // Esta ruta debería usar Sequelize en lugar del array local
    Estudiante.create({
        nombre: req.body.nombre,
        edad: parseInt(req.body.edad),
        inscrito: req.body.inscrito === true || req.body.inscrito === 'true'
    })
        .then(estudiante => {
            res.send(estudiante);
        })
        .catch(error => {
            console.error('Error al crear estudiante:', error);
            res.status(500).send({ error: 'Error al crear estudiante' });
        });
});

app.delete('/api/estudiantes/:id', (req, res) => {
    // Esta ruta debería usar Sequelize en lugar del array local
    Estudiante.findByPk(parseInt(req.params.id))
        .then(estudiante => {
            if (!estudiante) return res.status(404).send('Estudiante no encontrado');
            return estudiante.destroy().then(() => {
                res.send({ message: 'Estudiante eliminado', estudiante });
            });
        })
        .catch(error => {
            console.error('Error al eliminar estudiante:', error);
            res.status(500).send({ error: 'Error al eliminar estudiante' });
        });
});

// Obtenemos todas las aulas
app.get('/api/aulas', (req, res) => {
    Aulas.findAll().then(function(aulas) {
        res.send(aulas);
    }).catch(err => {
        res.status(500).send("Error al obtener aulas");
    });
});

// Buscar aula por materia
app.get('/api/aulas/:materia', (req, res) => {
    // Corregido: findByPk busca por clave primaria, probablemente quieras buscar por materia
    Aulas.findOne({
        where: {
            materia: req.params.materia
        }
    }).then(aula => {
        if (!aula) return res.status(404).send('Aula no encontrada');
        res.send(aula);
    }).catch(err => {
        res.status(500).send("Error al buscar aula");
    });
});

// Crear un aula
app.post('/api/aulas', (req, res) => {
    Aulas.create({
        salon: req.body.salon,
        materia: req.body.materia,
        docente: req.body.docente
    }).then(aula => {
        res.send(aula);
    }).catch(err => {
        res.status(500).send("Error al crear aula");
    });
});

// Sincroniza Sequelize y escucha en el puerto
sequelize.sync()
    .then(() => {
        console.log('Base de datos y tablas creadas');
        
        const port = process.env.PORT || 80;
        app.listen(port, () => {
            console.log(`Escuchando en puerto ${port}...`);
        });
    })
    .catch(err => {
        console.error('Error al conectar con la base de datos:', err);
    });

    // Al final de tu archivo app.js
// Sincroniza Sequelize y escucha en el puerto
sequelize.authenticate()
.then(() => {
    console.log('Conexión a la base de datos establecida exitosamente.');
    return sequelize.sync();
})
.then(() => {
    console.log('Base de datos y tablas creadas');
    
    const port = process.env.PORT || 3000;
    app.listen(port, () => {
        console.log(`Escuchando en puerto ${port}...`);
    });
})
.catch(err => {
    console.error('Error al conectar con la base de datos:', err);
    console.log('Iniciando servidor sin conexión a la base de datos...');
    
    const port = process.env.PORT || 3000;
    app.listen(port, () => {
        console.log(`Escuchando en puerto ${port} (sin conexión a la base de datos)...`);
        console.log('Usando datos en memoria para pruebas.');
    });
});