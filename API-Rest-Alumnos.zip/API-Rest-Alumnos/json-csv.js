// Importaciones necesarias
const fs = require('fs');
const path = require('path');

function jsonToCSV(jsonData) {
    // Si el JSON es un string, parsearlo
    if (typeof jsonData === 'string') {
        jsonData = JSON.parse(jsonData);
    }

    // Verificar si hay datos
    if (!jsonData || !jsonData.length) {
        return '';
    }

    // Obtener los encabezados del primer objeto
    const headers = Object.keys(jsonData[0]);
    
    // Crear la línea de encabezados
    const csvRows = [
        headers.join(',')
    ];

    // Convertir cada objeto a una línea CSV
    for (const row of jsonData) {
        const values = headers.map(header => {
            const value = row[header];
            // Manejar valores especiales
            if (value === null || value === undefined) {
                return '';
            }
            // Escapar comillas y envolver en comillas si contiene comas
            const escaped = String(value).replace(/"/g, '""');
            return /[,"\n]/.test(escaped) ? `"${escaped}"` : escaped;
        });
        csvRows.push(values.join(','));
    }

    // Unir todas las líneas con saltos de línea
    return csvRows.join('\n');
}

// Ejemplo de uso:
const jsonData = [
    { id: 1, nombre: 'Gonzalo', edad: 22, inscrito: true },
    { id: 2, nombre: 'Santiago', edad: 21, inscrito: true },
    { id: 3, nombre: 'Carlos', edad: 21, inscrito: true },
];

// Convertir a CSV
const csv = jsonToCSV(jsonData);

// Guardar el archivo (en el navegador)
function downloadCSV(csv) {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', 'datos.csv');
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function saveCSVToFile(jsonData, outputPath = 'datos.csv') {
    try {
        // Convertir jsonData a CSV
        const csv = jsonToCSV(jsonData);
        
        // Asegurarse de que la extensión sea .csv
        const filePath = outputPath.endsWith('.csv') ? outputPath : `${outputPath}.csv`;
        
        // Obtener la ruta absoluta
        const absolutePath = path.resolve(filePath);
        
        // Guardar el archivo
        fs.writeFileSync(absolutePath, csv, 'utf-8');
        
        console.log(`Archivo CSV guardado exitosamente en: ${absolutePath}`);
        return true;
    } catch (error) {
        console.error('Error al guardar el archivo CSV:', error.message);
        return false;
    }
}

// Ejemplo de uso para guardar en archivo
// saveCSVToFile(jsonData, 'datos_exportados');